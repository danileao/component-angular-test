export class MesModel {
  id: number;
  nome: string;


}
