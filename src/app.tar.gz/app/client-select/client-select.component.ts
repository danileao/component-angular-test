import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-cliente',
  templateUrl: './client-select.component.html',
})
export class ClientSelectComponent {


  public chamaEvento(event: any) {
    console.info('chamou');
    console.info(event);
  }
}
