import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {SelectComponent} from './select-component/select-component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {ClientSelectComponent} from './client-select/client-select.component';

@NgModule({
  declarations: [
    AppComponent,
    SelectComponent,
    ClientSelectComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
